import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, ContextTypes

# تفعيل اللوج
logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s", level=logging.INFO
)
logger = logging.getLogger(__name__)

TOKEN = "PUT-YOUR-TOKEN-HERE"

# البداية
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    keyboard = [
        [InlineKeyboardButton("📘 أساسيات ECG", callback_data="section1")],
        [InlineKeyboardButton("📊 القياسات", callback_data="section2")],
        [InlineKeyboardButton("❤️ الريثمات", callback_data="section3")],
        [InlineKeyboardButton("⚡️ الحالات الطارئة", callback_data="section4")],
        [InlineKeyboardButton("🩺 أمراض القلب", callback_data="section5")],
        [InlineKeyboardButton("💊 الأدوية وتأثيرها", callback_data="section6")],
        [InlineKeyboardButton("📝 الاختبار", callback_data="section7")],
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.message.reply_text("أهلاً 👋 أنا بوت ECG with Abu Eid
اختر القسم:", reply_markup=reply_markup)

# دوال الأقسام
async def button(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    section_texts = {
        "section1": "📘 قسم الأساسيات:
• ECG Paper
• Leads
• Calibration
• Electrodes Placement",
        "section2": "📊 قسم القياسات:
• Heart Rate
• PR Interval
• QRS Duration
• QT Interval
• Axis",
        "section3": "❤️ قسم الريثمات:
• Normal Sinus Rhythm
• Sinus Bradycardia
• Sinus Tachycardia
• AFib
• AFlutter
• SVT
• VT
• VF
• Asystole
• PEA
وغيرها كثير (أكثر من 40 حالة).",
        "section4": "⚡️ الحالات الطارئة:
• Cardiac Arrest
• STEMI
• NSTEMI
• Hyperkalemia ECG changes
• Hypokalemia ECG changes
• Hypocalcemia / Hypercalcemia",
        "section5": "🩺 أمراض القلب:
• LVH
• RVH
• LBBB
• RBBB
• WPW Syndrome
• Brugada Syndrome
• Long QT Syndrome",
        "section6": "💊 الأدوية وتأثيرها:
• Digoxin Effect
• Beta Blockers
• Calcium Channel Blockers
• Antiarrhythmic Drugs",
        "section7": "📝 قسم الاختبار:
جاوب على الأسئلة لمعرفة مستواك 🎯",
    }

    response = section_texts.get(query.data, "🚧 تحت التطوير")
    await query.edit_message_text(text=response)

def main():
    application = Application.builder().token(TOKEN).build()
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CallbackQueryHandler(button))
    application.run_polling()

if __name__ == "__main__":
    main()
